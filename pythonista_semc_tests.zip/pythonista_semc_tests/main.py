# -*- coding: utf-8 -*-
"""
Pythonista entry point.
WebView client fingerprint + local INF publisher lab.
"""

import json
import os
import socket
import threading

import inf_parser

HERE = os.path.dirname(os.path.abspath(__file__))
WWW = os.path.join(HERE, "www")
SAMPLES = os.path.join(HERE, "samples")
LAST_WEB = os.path.join(HERE, "last_webview.json")
LAST_INF = os.path.join(HERE, "last_inf.json")

try:
    import ui
    import console
    IN_PYTHONISTA = True
except ImportError:
    IN_PYTHONISTA = False
    ui = None


def _lan_ip():
    ip = "127.0.0.1"
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
    except Exception:
        pass
    return ip


class _QuietHandler(object):
    """http.server handler factory built later to avoid import cost on UI thread."""
    pass


def start_server(port=8765):
    from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

    class Handler(SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            super(Handler, self).__init__(*args, directory=WWW, **kwargs)

        def log_message(self, fmt, *args):
            return

    httpd = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    t = threading.Thread(target=httpd.serve_forever)
    t.daemon = True
    t.start()
    return httpd, "http://%s:%s/" % (_lan_ip(), port)


def format_inf_report(results):
    lines = []
    if not results:
        lines.append("No .inf / .txt / .log files in samples/ and nothing pasted.")
        lines.append("Drop exported INF text into samples/ or paste in the INF tab.")
        return "\n".join(lines)
    for item in results:
        c = item["classification"]
        p = item["parsed"]
        lines.append("=" * 60)
        lines.append(item["filename"])
        lines.append("risk=%s  tags=%s" % (c["risk"], ",".join(c["tags"]) or "-"))
        lines.append("Provider: %s" % (p.get("provider") or "(none)"))
        lines.append("CatalogFile: %s" % (p.get("catalog_file") or "(none)"))
        lines.append("Class: %s  %s" % (p.get("class"), p.get("class_guid")))
        lines.append("DriverVer: %s" % p.get("driver_ver"))
        lines.append("Signature: %s" % p.get("signature"))
        if p.get("hardware_ids"):
            lines.append("Hardware IDs:")
            for h in p["hardware_ids"]:
                lines.append("  " + h)
        if p.get("coinstaller_hits"):
            lines.append("Co-installer hits:")
            for h in p["coinstaller_hits"]:
                lines.append("  " + h)
        if p.get("media"):
            lines.append("Media (SourceDisksNames):")
            for m in p["media"][:8]:
                lines.append("  " + m["line"])
        lines.append("Notes:")
        for n in c["notes"]:
            lines.append("  - " + n)
    return "\n".join(lines)


if IN_PYTHONISTA:

    class App(ui.View):
        def __init__(self):
            ui.View.__init__(self)
            self.flex = "WH"
            self.background_color = "#f4f1ea"
            self.httpd = None
            self.server_url = None
            self.last_web = {}

            self.tabs = ui.SegmentedControl()
            self.tabs.segments = ["WebView", "INF lab", "Notes"]
            self.tabs.selected_index = 0
            self.tabs.action = self._tab
            self.add_subview(self.tabs)

            self.web = ui.WebView()
            self.web.flex = "WH"
            self.add_subview(self.web)

            self.inf_box = ui.TextView()
            self.inf_box.font = ("Menlo", 12)
            self.inf_box.editable = True
            self.inf_box.text = ""
            self.add_subview(self.inf_box)

            self.notes = ui.TextView()
            self.notes.editable = False
            self.notes.font = ("Menlo", 12)
            self.notes.text = open(os.path.join(HERE, "README.md"), "r").read()
            self.add_subview(self.notes)

            self.bar = ui.View()
            self.bar.background_color = "#1a1a1a"
            self.add_subview(self.bar)

            def mkbtn(title, action, x):
                b = ui.Button(title=title)
                b.action = action
                b.tint_color = "white"
                b.font = ("<System>", 13)
                b.frame = (x, 6, 90, 32)
                self.bar.add_subview(b)
                return b

            mkbtn("Re-run", self._rerun, 8)
            mkbtn("Safari", self._safari, 100)
            mkbtn("LAN", self._lan, 192)
            mkbtn("Parse INF", self._parse_paste, 284)
            mkbtn("Scan dir", self._scan, 376)

            self._layout_now()
            self._show(0)
            index = os.path.join(WWW, "index.html")
            self.web.load_url("file://" + index)

        def layout(self):
            self._layout_now()

        def _layout_now(self):
            w, h = self.width or 390, self.height or 720
            self.bar.frame = (0, 0, w, 44)
            self.tabs.frame = (8, 50, w - 16, 32)
            body = (0, 90, w, h - 90)
            self.web.frame = body
            self.inf_box.frame = body
            self.notes.frame = body

        def _tab(self, sender):
            self._show(sender.selected_index)

        def _show(self, idx):
            self.web.hidden = idx != 0
            self.inf_box.hidden = idx != 1
            self.notes.hidden = idx != 2

        def _rerun(self, sender):
            try:
                raw = self.web.eval_js("JSON.stringify(runEnvTests())")
                if raw:
                    self.last_web = json.loads(raw)
                    with open(LAST_WEB, "w") as f:
                        json.dump(self.last_web, f, indent=2)
                    console.hud_alert("WebView tests captured", "success", 1)
            except Exception as e:
                console.hud_alert(str(e), "error", 2)

        def _safari(self, sender):
            import webbrowser
            index = os.path.join(WWW, "index.html")
            webbrowser.open("file://" + index)

        def _lan(self, sender):
            if self.httpd is None:
                self.httpd, self.server_url = start_server()
            console.alert("LAN server", "Other party can open:\n" + self.server_url + "\nSame Wi-Fi only. This fingerprints THEIR browser, not their DriverStore.", "OK")

        def _parse_paste(self, sender):
            text = self.inf_box.text.strip()
            if not text:
                console.hud_alert("Paste INF text first", "error", 1.5)
                return
            report = inf_parser.analyse_text(text, "pasted.inf")
            with open(LAST_INF, "w") as f:
                json.dump(report, f, indent=2)
            self.inf_box.text = format_inf_report([report])
            self.tabs.selected_index = 1
            self._show(1)

        def _scan(self, sender):
            results = inf_parser.scan_dir(SAMPLES)
            with open(LAST_INF, "w") as f:
                json.dump(results, f, indent=2)
            self.inf_box.text = format_inf_report(results)
            self.tabs.selected_index = 1
            self._show(1)

    def main():
        v = App()
        v.present("fullscreen")

else:
    def main():
        print("Not Pythonista — running headless INF scan + parser self-check")
        results = inf_parser.scan_dir(SAMPLES)
        print(format_inf_report(results))


if __name__ == "__main__":
    main()
