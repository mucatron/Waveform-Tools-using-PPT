# -*- coding: utf-8 -*-
import os
import inf_parser

HERE = os.path.dirname(os.path.abspath(__file__))
SAMPLES = os.path.join(HERE, "samples")


def main():
    results = inf_parser.scan_dir(SAMPLES)
    assert len(results) >= 2, results
    tags = set()
    for r in results:
        tags.update(r["classification"]["tags"])
        print(r["filename"], r["classification"]["tags"], r["classification"]["risk"])
        print("  provider:", r["parsed"]["provider"])
        print("  catalog:", r["parsed"]["catalog_file"])
        print("  hw:", r["parsed"]["hardware_ids"])
    assert "SONY" in tags or "FELICA" in tags
    assert "SEMC" in tags
    print("OK", sorted(tags))


if __name__ == "__main__":
    main()
