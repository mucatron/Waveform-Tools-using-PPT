# Run on the Windows machine you are allowed to inspect.
# Saves a text export you can send to the lab (paste into Pythonista INF tab).
# Does not install software, does not change drivers.

$Out = Join-Path $env:USERPROFILE "Desktop\driver_export.txt"
$lines = @()
$lines += "=== COMPUTER ==="
$lines += "Manufacturer=$([Environment]::GetEnvironmentVariable('COMPUTERNAME'))"
$lines += "OS=$([System.Environment]::OSVersion.VersionString)"
$lines += "Arch=$env:PROCESSOR_ARCHITECTURE"
$lines += ""

$lines += "=== PNPUTIL (published packages) ==="
try { $lines += (pnputil /enum-drivers) } catch { $lines += $_.Exception.Message }

$lines += ""
$lines += "=== Get-WindowsDriver -Online (first 200) ==="
try {
  $d = Get-WindowsDriver -Online -ErrorAction Stop |
    Select-Object -First 200 ProviderName, ClassName, Driver, OriginalFileName, Date, Version
  $lines += ($d | Format-List | Out-String)
} catch { $lines += $_.Exception.Message }

$lines += ""
$lines += "=== Sony / SEMC / FeliCa filename hits under INF + DriverStore ==="
$roots = @(
  "$env:WINDIR\INF",
  "$env:WINDIR\System32\DriverStore\FileRepository"
)
foreach ($root in $roots) {
  if (Test-Path $root) {
    Get-ChildItem $root -Recurse -ErrorAction SilentlyContinue |
      Where-Object { $_.Name -match 'sony|semc|felica|pasori|nfcport|xperia|companion' } |
      Select-Object -First 80 FullName, Length, LastWriteTime |
      ForEach-Object { $lines += ("{0}`t{1}`t{2}" -f $_.LastWriteTime, $_.Length, $_.FullName) }
  }
}

$lines | Set-Content -Path $Out -Encoding UTF8
Write-Host "Wrote $Out"
Write-Host "Send that file. Do not send secrets from other folders."
