# SEMC / Sony Windows surface — Pythonista + WebView tests

Defensive lab suite. It runs on iOS in **Pythonista** (WebView + Python) and does two things only:

1. **WebView environment tests** — if the other party *opens this page* (browser or in-app WebView), fingerprint *their* client: OS family, browser, language, timezone, WebGL/WebView hints, network-facing headers.
2. **INF / media publisher tests** — parse `.inf`, `.cat` names, and INF `[SourceDisks*]` media sections *you already have* (AirDrop, Files app, paste). Report Provider, CatalogFile, Class, hardware IDs, and whether they match known Sony / SEMC / FeliCa / Xperia Windows packages.

## What this does not do

- It cannot read another PC’s `C:\Windows\INF` or DriverStore from a webpage or from Pythonista.
- It does not emulate USB devices, speak PnP, or implement Plug-and-Pwn / MITM chains.
- It does not exploit co-installers or rewrite driver catalogs.

If you need a remote driver-store inventory, the other party must export it themselves (e.g. `Get-WindowsDriver -Online`) and hand you the text.

## Run in Pythonista

1. Copy the whole `pythonista_semc_tests` folder into Pythonista (iCloud or Files → Pythonista).
2. Open `main.py` and tap Run.
3. **WebView** tab: tests run in the embedded WKWebView. Use *Open in Safari* if you want the other party to load the same page on their machine (start the local server first).
4. **INF lab** tab: tap *Pick / paste INF* or drop files into `samples/`.
5. Optional: tap *Start LAN server* and give the other party `http://<your-iphone-ip>:8765/` so *their* browser is the client under test.

Pythonista 3.x, iOS 15+. No third-party pip packages.

## Interpreting results

| Signal | Meaning |
|---|---|
| UA / Client Hints say Windows + `Edg` / `Chrome` | Client is a desktop browser, not this iPhone WebView |
| `wv` / `iPhone` / `Pythonista` in UA | Tests are running inside this app, not the remote PC |
| INF `Provider` = Sony Corporation / Sony Mobile / Sony Ericsson | Package claims that publisher (Authenticode may still differ) |
| Hardware IDs with `VID_054C` or `VID_0FCE` | Sony Corp USB vs legacy Sony Ericsson USB |
| `felica`, `sonynfcport`, `coinst` | FeliCa / NFC Port Windows stack (PnP co-installer class) |
| `PC Companion`, `Xperia Companion`, `PCCService` | SEMC desktop middlebox |
| CatalogFile present, no signed `.cat` next to it | Incomplete package; publisher cannot be verified here |

Publisher *of the signature* lives in the `.cat` / Authenticode cert. This suite reads INF-declared Provider + CatalogFile name. Full cert chain checks need a Windows box or `sigcheck`/`Get-AuthenticodeSignature`.
