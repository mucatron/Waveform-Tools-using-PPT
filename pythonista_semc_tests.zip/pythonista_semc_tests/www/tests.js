(function () {
  function row(k, v) {
    return "<tr><td>" + esc(k) + "</td><td><code>" + esc(String(v)) + "</code></td></tr>";
  }
  function esc(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function card(title, html) {
    return '<div class="card"><strong>' + esc(title) + "</strong>" + html + "</div>";
  }

  function uaParse(ua) {
    var os = "unknown";
    if (/Windows NT 10/i.test(ua)) os = "Windows 10/11 family";
    else if (/Windows NT 6\.1/i.test(ua)) os = "Windows 7";
    else if (/Windows/i.test(ua)) os = "Windows (other)";
    else if (/iPhone|iPad|iPod/i.test(ua)) os = "iOS / iPadOS";
    else if (/Macintosh/i.test(ua)) os = "macOS (or iPad desktop UA)";
    else if (/Android/i.test(ua)) os = "Android";
    else if (/Linux/i.test(ua)) os = "Linux";

    var engine = "unknown";
    if (/Edg\//.test(ua)) engine = "Chromium Edge";
    else if (/Chrome\//.test(ua) && /Safari\//.test(ua)) engine = "Chrome / Chromium";
    else if (/FxiOS|Firefox\//.test(ua)) engine = "Firefox";
    else if (/Safari\//.test(ua) && /Version\//.test(ua)) engine = "Safari";
    else if (/AppleWebKit/.test(ua)) engine = "WebKit (app WebView likely)";

    var hints = [];
    if (/Pythonista/i.test(ua)) hints.push("Pythonista");
    if (/wv\)|; wv/.test(ua) || /Version\/4\.0/.test(ua) && /AppleWebKit/.test(ua) && !/Safari\//.test(ua)) hints.push("embedded WebView pattern");
    if (window.webkit && window.webkit.messageHandlers) hints.push("webkit.messageHandlers present");
    if (window.chrome && chrome.webview) hints.push("Edge/WebView2 chrome.webview");
    return { os: os, engine: engine, hints: hints };
  }

  function collect() {
    var nav = navigator;
    var ua = nav.userAgent || "";
    var parsed = uaParse(ua);
    var ch = nav.userAgentData || null;
    var conn = nav.connection || nav.mozConnection || nav.webkitConnection || {};
    var glInfo = { vendor: "", renderer: "" };
    try {
      var c = document.createElement("canvas");
      var gl = c.getContext("webgl") || c.getContext("experimental-webgl");
      if (gl) {
        var ext = gl.getExtension("WEBGL_debug_renderer_info");
        glInfo.vendor = gl.getParameter(ext ? ext.UNMASKED_VENDOR_WEBGL : gl.VENDOR);
        glInfo.renderer = gl.getParameter(ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER);
      }
    } catch (e) {
      glInfo.error = String(e);
    }

    var storage = {};
    try { storage.local = !!window.localStorage; } catch (e) { storage.local = false; }
    try { storage.session = !!window.sessionStorage; } catch (e) { storage.session = false; }

    return {
      href: location.href,
      origin: location.origin,
      protocol: location.protocol,
      ua: ua,
      uaPlatform: nav.platform,
      uaVendor: nav.vendor,
      language: nav.language,
      languages: nav.languages,
      hwConcurrency: nav.hardwareConcurrency,
      deviceMemory: nav.deviceMemory,
      maxTouch: nav.maxTouchPoints,
      cookieEnabled: nav.cookieEnabled,
      online: nav.onLine,
      pdfViewer: nav.pdfViewerEnabled,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      locale: Intl.DateTimeFormat().resolvedOptions().locale,
      screen: {
        w: screen.width, h: screen.height,
        aw: screen.availWidth, ah: screen.availHeight,
        dpr: window.devicePixelRatio, colorDepth: screen.colorDepth
      },
      parsed: parsed,
      clientHints: ch ? {
        mobile: ch.mobile,
        brands: (ch.brands || []).map(function (b) { return b.brand + " " + b.version; }),
        platform: ch.platform
      } : null,
      connection: { type: conn.type, effectiveType: conn.effectiveType, downlink: conn.downlink },
      webgl: glInfo,
      storage: storage,
      plugins: (nav.plugins ? Array.from(nav.plugins).map(function (p) { return p.name; }) : []).slice(0, 12),
      isSecureContext: window.isSecureContext,
      pythonistaBridge: typeof window.__py_report === "function"
    };
  }

  function verdict(data) {
    var lines = [];
    lines.push("OS guess: " + data.parsed.os);
    lines.push("Engine guess: " + data.parsed.engine);
    if (data.parsed.hints.length) lines.push("Hints: " + data.parsed.hints.join(", "));
    if (/Windows/i.test(data.parsed.os)) {
      lines.push("This client looks like a Windows browser — INF DriverStore is still not readable from here.");
    }
    if (/iOS/i.test(data.parsed.os)) {
      lines.push("This client looks like iOS. Sony SEMC Windows packages are not present on this device.");
    }
    if (data.pythonistaBridge) lines.push("Pythonista bridge is active.");
    return lines;
  }

  function render(data) {
    var html = "";
    html += card("Verdict", "<ul>" + verdict(data).map(function (l) { return "<li>" + esc(l) + "</li>"; }).join("") + "</ul>");
    html += card("Identity", "<table>" +
      row("userAgent", data.ua) +
      row("platform", data.uaPlatform) +
      row("vendor", data.uaVendor) +
      row("language", data.language) +
      row("languages", (data.languages || []).join(", ")) +
      row("timezone", data.timezone) +
      row("locale", data.locale) +
      "</table>");
    html += card("Device / media", "<table>" +
      row("screen", data.screen.w + "x" + data.screen.h + " @" + data.screen.dpr) +
      row("touch points", data.maxTouch) +
      row("CPU threads", data.hwConcurrency) +
      row("deviceMemory GiB", data.deviceMemory) +
      row("WebGL vendor", data.webgl.vendor) +
      row("WebGL renderer", data.webgl.renderer) +
      row("connection", JSON.stringify(data.connection)) +
      "</table>");
    html += card("Client hints / plugins", "<pre>" + esc(JSON.stringify({
      clientHints: data.clientHints,
      plugins: data.plugins,
      secure: data.isSecureContext,
      href: data.href
    }, null, 2)) + "</pre>");
    html += card("Raw JSON", "<pre id='raw'>" + esc(JSON.stringify(data, null, 2)) + "</pre>");
    document.getElementById("out").innerHTML = html;
    if (typeof window.__py_report === "function") {
      window.__py_report(JSON.stringify(data));
    }
    return data;
  }

  window.runEnvTests = function () {
    document.getElementById("status").textContent = " running…";
    var data = collect();
    render(data);
    document.getElementById("status").textContent = " done";
    return data;
  };

  document.getElementById("run").addEventListener("click", function () {
    window.runEnvTests();
  });
  window.addEventListener("load", function () {
    window.runEnvTests();
  });
})();
