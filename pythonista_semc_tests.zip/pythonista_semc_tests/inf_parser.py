# -*- coding: utf-8 -*-
"""Parse Windows INF text for Provider, CatalogFile, media, hardware IDs."""

import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))


def _load_rules():
    path = os.path.join(HERE, "known_publishers.json")
    with open(path, "r") as f:
        return json.load(f)


def _strip_comment(line):
    in_quote = False
    out = []
    for ch in line:
        if ch == '"':
            in_quote = not in_quote
        if ch == ";" and not in_quote:
            break
        out.append(ch)
    return "".join(out).strip()


def parse_inf(text):
    sections = {}
    current = "_preamble"
    sections[current] = []
    for raw in text.splitlines():
        line = _strip_comment(raw)
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            current = line[1:-1].strip()
            sections.setdefault(current, [])
            continue
        sections[current].append(line)

    kv = {}
    version = sections.get("Version", [])
    for line in version:
        if "=" in line:
            k, v = line.split("=", 1)
            kv[k.strip().lower()] = v.strip().strip('"')

    strings = {}
    for line in sections.get("Strings", []):
        if "=" in line:
            k, v = line.split("=", 1)
            strings[k.strip().lower()] = v.strip().strip('"')

    def expand(val):
        if not val:
            return val
        def repl(m):
            return strings.get(m.group(1).lower(), m.group(0))
        return re.sub(r"%([^%]+)%", repl, val)

    provider = expand(kv.get("provider", ""))
    catalog = expand(kv.get("catalogfile", "") or kv.get("catalogfile.nt", "") or kv.get("catalogfile.ntamd64", "") or kv.get("catalogfile.ntarm64", ""))
    signature = expand(kv.get("signature", ""))
    class_name = expand(kv.get("class", ""))
    class_guid = expand(kv.get("classguid", ""))
    driver_ver = expand(kv.get("driverver", ""))

    media = []
    for key in ("SourceDisksNames", "SourceDisksNames.amd64", "SourceDisksNames.x86", "SourceDisksNames.ntamd64"):
        for line in sections.get(key, []):
            media.append({"section": key, "line": expand(line)})
    files = []
    for key in list(sections.keys()):
        if key.lower().startswith("sourcedisksfiles"):
            for line in sections[key]:
                files.append({"section": key, "line": expand(line)})

    hw_ids = []
    hw_re = re.compile(r"(USB\\VID_[0-9A-F]{4}&PID_[0-9A-F]{4}(?:&MI_[0-9A-F]{2})?)", re.I)
    for sect, lines in sections.items():
        for line in lines:
            exp = expand(line)
            for m in hw_re.findall(exp):
                hw_ids.append(m.upper())
    # unique preserve order
    seen = set()
    hw_unique = []
    for h in hw_ids:
        if h not in seen:
            seen.add(h)
            hw_unique.append(h)

    coinstallers = []
    for sect, lines in sections.items():
        if "coinstaller" in sect.lower() or "coinst" in sect.lower():
            coinstallers.append(sect)
        for line in lines:
            if re.search(r"coinst|coinstaller", line, re.I):
                coinstallers.append(expand(line))

    return {
        "signature": signature,
        "provider_raw": kv.get("provider", ""),
        "provider": provider,
        "catalog_file": catalog,
        "class": class_name,
        "class_guid": class_guid,
        "driver_ver": driver_ver,
        "media": media[:40],
        "source_files": files[:80],
        "hardware_ids": hw_unique[:40],
        "coinstaller_hits": coinstallers[:20],
        "section_count": len(sections),
        "has_version_section": "Version" in sections,
    }


def classify(parsed, filename=""):
    rules = _load_rules()
    blob = " ".join([
        filename,
        parsed.get("provider") or "",
        parsed.get("catalog_file") or "",
        parsed.get("class") or "",
        " ".join(parsed.get("hardware_ids") or []),
        " ".join(parsed.get("coinstaller_hits") or []),
        " ".join(m.get("line", "") for m in parsed.get("media") or []),
        " ".join(f.get("line", "") for f in parsed.get("source_files") or []),
    ]).lower()

    tags = []
    notes = []
    risk = "info"

    for row in rules["providers"]:
        if row["match"] in blob:
            tags.append(row["tag"])
            notes.append(row["note"])
    for row in rules["filenames"]:
        if row["match"] in blob:
            tags.append(row["tag"])
            notes.append(row["note"])
            if row.get("risk") == "high":
                risk = "high"
            elif row.get("risk") == "medium" and risk != "high":
                risk = "medium"
    for row in rules["hardware_ids"]:
        if row["match"].lower() in blob:
            tags.append(row["tag"])
            notes.append(row["note"])

    # de-dupe tags
    tag_seen = set()
    tags_u = []
    for t in tags:
        if t not in tag_seen:
            tag_seen.add(t)
            tags_u.append(t)

    if not parsed.get("has_version_section"):
        notes.append("No [Version] section — may not be a Windows INF")
        if risk == "info":
            risk = "low"

    if parsed.get("catalog_file"):
        notes.append("CatalogFile declared — Authenticode publisher is in the .cat, not fully visible from INF text")
    else:
        notes.append("No CatalogFile — package may be unsigned or using a sibling CAT name")

    return {"tags": tags_u, "notes": notes, "risk": risk}


def analyse_text(text, filename="pasted.inf"):
    parsed = parse_inf(text)
    classif = classify(parsed, filename)
    return {"filename": filename, "parsed": parsed, "classification": classif}


def analyse_path(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    return analyse_text(text, os.path.basename(path))


def scan_dir(folder):
    results = []
    if not os.path.isdir(folder):
        return results
    for name in sorted(os.listdir(folder)):
        if name.lower().endswith((".inf", ".txt", ".log")):
            results.append(analyse_path(os.path.join(folder, name)))
    return results
